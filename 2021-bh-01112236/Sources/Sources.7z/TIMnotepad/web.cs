﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TIMnotepad
{
    public partial class web : Form
    {
        public web()
        {
            InitializeComponent();
            button1.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.BorderSize = 0;
            Encoding encoding = Encoding.GetEncoding("utf-8");
            string fileText = File.ReadAllText("files/site.t$");
            webBrowser1.Navigate("file:///" + fileText);
            webBrowser1.IsWebBrowserContextMenuEnabled = false;
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Width = Convert.ToInt32(width.Text);
            this.Height = Convert.ToInt32(height.Text);
        }
    }
}
